# Same as release.bat but for unix
7z a -tzip -i!assets -i!flixel -i!images -i!CHANGELOG.md -i!LICENSE.md -i!README.md -i!include.xml -i!haxelib.json -i!run.n flixel.zip